<template>
  <div >
      <h1>reg组件--{{abc}}</h1>

      <hr>
      <h2>testdata-----{{　testData}}</h2>
       
  </div>
</template>

<script>


export default {
  async asyncData({app}){
　　        let res =await app.$axios({
              　　headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              　　method: 'get',
              　　url: `http://test.yms.cn/testjson.asp`,
              　　data: ''

        　　})
        // app.$axios
        console.log('app',app.$axios)
        　　console.log('res',res.data)
        　　return{
        　      　testData:res.data.title
        　　}
    },
    data(){
      return {
        abc:11111
      }
    },
    async created(){
      console.log('nuxt reg组件-created')
      let res =await this.$axios({
              　　method: 'get',
              　　url: `http://122.51.238.153/crostest.php`,
              　　data: ''

        　　})
        console.log('cccc',res)
    }
    
}
</script>

<style>

</style>
