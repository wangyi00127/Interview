<template>
  <div>
      <h1>indexBBBB啊啊啊啊啊</h1>
  </div>
</template>

<script>

export default {

    data(){
       return {
          
       }
    },
    created(){

    },
    mounted(){
    
    }

}
</script>

<style>




</style>