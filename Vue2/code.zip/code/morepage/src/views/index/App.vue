<template>
  <div id="app">
    首页home
    <a href="ui.html">去ui阿</a>
    <hr>
    <router-link to="/indexa">切换去indexA</router-link>
    <hr>
     <router-view></router-view>
  </div>
</template>

<script>


export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
