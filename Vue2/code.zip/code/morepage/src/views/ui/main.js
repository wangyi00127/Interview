import Vue from 'vue'
import Ui from './Ui.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(Ui)
}).$mount('#ui')
