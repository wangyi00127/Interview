<template>
  <div id="app">
    ui页面啊啊啊
    <!-- 现在他是两套文件了 a标签跳转是会重新刷新页面的
      其实不太好 所以这个很少用

      因为 你不如直接创建两个项目
      用不用 我们很少 但是如果别人用到了 你能看到
       面试 会问一下  多页面大概配置
     -->
    <a href="index.html">去home页面</a>
  </div>
</template>

<script>


export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
