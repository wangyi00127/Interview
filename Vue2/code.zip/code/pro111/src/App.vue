<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div>
    <!-- <keep-alive> -->
      <!-- 里面是当需要缓存时 -->
      <!-- <router-view  v-if="$route.meta.isAlive" /> -->
    <!-- </keep-alive> -->
     <!-- 外面是不需要缓存时 -->
    <!-- <router-view  v-if="!$route.meta.isAlive" /> -->

   <!-- 是所有组件都需要缓存吗？不是 所以这里需要一个判断
         如果组件不需要缓存 就走  <router-view></router-view>
         如果组件需要缓存比如list列表 走 
           <keep-alive>
              <router-view></router-view>
          </keep-alive>
          怎么判断呢？
     -->
    <!-- 这样写的 组件显示 就不会缓存 
    在路由里面配置的meta 可以直接使用
    $route获取

    现在我配置 了 home 不需要缓存
       home  每次都重新创建--生命周期会走一遍
       about需要缓存 --你再回到about组件 他不会重新创建一遍
    -->
    <router-view v-if="!$route.meta.isAlive"></router-view>
    <!-- 如果组件需要缓存 用keep-alive 包裹起来 -->
    <keep-alive>
        <router-view v-if="$route.meta.isAlive"></router-view>
    </keep-alive>
    
  </div>
</template>

<script>

export default {
  created(){
    // console.log('$route',this.$route)
  }
}

</script>


<style lang="less">
*{
  margin: 0;
  padding: 0;
}
li{
  list-style: none;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
