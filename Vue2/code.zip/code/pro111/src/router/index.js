import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    // meta 标识符 也是路由配置里面可以写的
    // 他可以用来 判断一些操作
    meta:{
      // 名字：值
      isAlive:false // 我想 isAlive false代表不缓存
      // 需要缓存的就在这写成 isAlive:true
    }
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue'),
    meta:{
      isAlive:true // about组件 需要缓存
    }
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// // 路由导航守卫
// router.beforeEach((to, from, next) => {
//   　　　　//判断user信息是否已经获取 我已经登录了
//           // 登录后就 把 后台给我的路由数组 addRouter就行
//           if (token) {
//   　　　　　　　　//根据用户的角色类型来生成对应的新路由
//               //  在这里要用 登录时候后台返回的 路由数组
//               // 建议大家 把那个数组 写在 vuex里面
//               // 从vuex 拿出 登录时候存的 newRouter
//               // 1 你提前写好 会有所有人能看的 一些 默认的
//               // 2 不同的 登录再追加
//               // this.$store.state.newRouter
//               // const newRouter = [{path:"/xxx" ...} ..]
//               //将新路由添加到路由中
//               // router.addRoutes vue带的专门迎来追加路由的
//               //　router.addRoutes(newRouter)
//   　　　　　　　　//为了正确渲染导航,将对应的新的路由添加到vuex中
//                   // 渲染对应的侧边栏
//           }
// })

export default router
