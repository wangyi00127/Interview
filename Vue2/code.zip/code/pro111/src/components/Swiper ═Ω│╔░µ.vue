<template>
  <div>
      轮播图
      <div class="box">
          <ul class="inner"  :style="{ left: leftPosition+'px'}">
              <li class="item" v-for="item in list" :key="item.id">
                  <img :src='item.src' alt="">
              </li>
          </ul>
      </div>
  </div>
</template>

<script>

export default {
  props:{
      list:{
        type:Array,
        default:()=>[]
      }
  },
    data(){
        return {
          //  list:,
           leftPosition:0
        }
    },
    mounted(){
        let i=0
        setInterval(()=>{
            i++
            if(i>=4){
              i=0
            }
            this.leftPosition=-i*300
        },2000)
    }
}

</script>

<style>

.box{
  width: 300px;
  height: 300px;
  border: 1px solid red;
  overflow: hidden;
}

.box .inner{
  width: 1200px;
  position: relative;
  transition: left 1s;
}

.box .inner li {
  float: left;
  width: 300px;
  height: 300px;
}

.box .inner li img{
   width: 100%;
   height: 100%;
}

</style>