<template>
  <div class="about">
    <h1>about页面</h1>
    <h1>count的值{{$store.state.count}}</h1>
<!-- 
    <my-swiper></my-swiper> -->
  </div>
</template>


<script>
// about 已经缓存了 不会再重新来一遍 
// 那如果我非要数据重新再请求  vue知道这种事 会有需求
// 所以 他提供了 另外两个生命周期函数 
// activated 组件激活  缓存之后 其他的不会走 但是这个每次进去都触发
// deactivated 组件走了

// 1 怎么缓存？  keep alive
// 2 缓存了 我突然需要缓存的组件 重新发送请求换数据？
//     缓存的组件还提供了activated生命周期 可以在这里面重新发送请求 
// 需要缓存的组件？ 最常见的事  列表(因为很长 到详情页返回 又回到列表)
//大家 去百度一下 然后我这个思路 大家跟着看 

// this.$router.push 跳转吗？
// $route 不带r 比较少 keep-alive用了一下  获取参数
// 记不住 就用一下或者先打印一下
export default {
  name:"about",
  created(){
    console.log("about 的 created")
  },
  mounted(){
    console.log("about 的 mounted")
  },
  update(){
    console.log("about 的 update")
  },
  activated(){
    // 判断 一下 再请求
     console.log("about 的 activated")
  }
}

</script>

<style>


</style>
