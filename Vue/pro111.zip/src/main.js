import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'
Vue.config.productionTip = false
Vue.prototype.$http=axios

import Swiper from './components/Swiper.vue'
Vue.component("my-swiper",Swiper)
// Vue.component("组件标签名",组件)
// <my-swiper></my-swiper>

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
