<template>
  <div class="about">
    <h1>about页面</h1>
    <h1>count的值{{$store.state.count}}</h1>
<!-- 
    <my-swiper></my-swiper> -->
  </div>
</template>


<script>

export default {
  name:"about",
  created(){
    console.log("about 的 created")
  },
  mounted(){
    console.log("about 的 mounted")
  },
  update(){
    console.log("about 的 update")
  },
  activated(){
     console.log("about 的 activated")
  }
}

</script>

<style>


</style>
