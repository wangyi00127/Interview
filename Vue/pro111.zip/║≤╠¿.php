<?php
// 所有后台设置头部 而且 代码都类似
header('Access-Control-Allow-Origin:*'); // *代表允许任何网址请求
header('Access-Control-Allow-Methods:POST,GET,OPTIONS,DELETE'); // 允许请求的类型


echo '成功请求'

?>