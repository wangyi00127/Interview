const State = {
  pending: "pending",
  resolved: "rejected",
  rejected: "rejected"
};

const noop = () => {};

class MyPromise {
  constructor(exclutor) {
    exclutor(this._resolve.bind(this), this._reject);
  }
  _state = State.pending;
  _value;
  _resolve(val) {
    if (this._state === State.pending) {
      this._value = val;
      this._state = State.resolved;

      this._runResolveArray();
    }
  }
  _reject() {}
  _runResolveArray() {
    //执行 then 传入进来的 onRes
    this._resArray.forEach(item => {
      // const item
      const result = item.handle(this._value);
      const nextPromise = item.promise;

      if (result instanceof MyPromise) {
        result.then(val => item.promise._resolve(val));
      } else {
        item.promise._resolve(result);
      }
    });
  }

  _resArray = [];

  then(onRes, onRej = noop) {
    // if (this._state === State.pending) {
    const newPromise = new MyPromise(() => {});
    const item = { promise: newPromise, handle: onRes };
    this._resArray.push(item);

    // }
    if (this._state === State.resolved) {
      this._runResolveArray();
    }
    return newPromise;
  }
}

export default MyPromise;
