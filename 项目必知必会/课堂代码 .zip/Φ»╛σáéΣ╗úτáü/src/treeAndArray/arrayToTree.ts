const arrayToTree = arr => {
  // + 处理 root
  // + 实现 addChildren 方法
  // + 执行 addChildren
};

export default arrayToTree;

const arr = [1];
const [a] = arr;
console.log(a);
