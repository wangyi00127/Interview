enum State {
  pending = "pending",
  resolved = "rejected",
  rejected = "rejected"
}
type ItemObj = {
  handle: any;
  promise: MyPromise;
};
const noop = () => {};
class MyPromise {
  constructor(exclutor) {
    const that = this;
    exclutor.apply(that, [this._resolve.bind(this), this._reject.bind(this)]);
  }
  _resolveArray: ItemObj[] = [];
  _rejectArray: ItemObj[] = [];
  _state: State = State.pending;
  _value: any = undefined;

  _runResolveArray() {
    while (this._resolveArray.length) {
      const item = this._resolveArray.shift();

      const result = item.handle(this._value);

      if (result instanceof MyPromise) {
        result.then(val => {
          item.promise._resolve(val);
        });
      } else {
        item.promise._resolve(result);
      }
    }
  }
  _resolve(val: any) {
    if (State.pending === this._state) {
      this._value = val;
      this._runResolveArray();
      this._state = State.resolved;
    }
  }
  _reject() {}

  then(onResolved, onRejected = noop) {
    const nextPromise = new MyPromise(() => {});
    const itemObj: ItemObj = { handle: onResolved, promise: nextPromise };
    this._resolveArray.push(itemObj);

    if (this._state === State.resolved) {
      this._runResolveArray();
    }

    return nextPromise;
  }
}

export default MyPromise;
