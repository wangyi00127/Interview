import { Node, Item } from "./data";
const treeToArray = (node: Node) => {
  const nodeToArray = (node: Node, arr: Item[]) => {
    const { children, ...item } = node;
    arr.push(item);
    children.forEach(child => nodeToArray(child, arr));
    return arr;
  };
  return nodeToArray(node, []);
};

export default treeToArray;
