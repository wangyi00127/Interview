import { Item, Node } from "./data";
// + 实现函数签名
// + 实现函数体
//   + 处理 root
//   + 实现 addChildren 方法
//   + 执行 addChildren

const arrayToTree = (arr: Item[]) => {
  if (!Array.isArray(arr) || arr.length < 1) return null;
  const [root] = arr.filter(item => item.parentId === null);
  const addChildren = (node, dataList: Item[]) => {
    const children = dataList
      .filter(item => item.parentId === node.id)
      .map(item => addChildren(item, dataList));
    return { ...node, children };
  };
  return addChildren(root, arr);
};

export default arrayToTree;
