import arrayToTree from "./arrayToTree";
import { originData, treeData } from "./data";

test("arrayToTee", () => {
  expect(arrayToTree(originData)).toEqual(treeData);
});
