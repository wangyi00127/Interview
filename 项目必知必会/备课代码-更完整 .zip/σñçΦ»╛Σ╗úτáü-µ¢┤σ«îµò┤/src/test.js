// const openDoor = cb => {
//   setTimeout(cb, 1000);
// };

const promise = () =>
  new Promise((res, rej) => {
    setTimeout(() => {
      res();
    }, 1000);
  });

function promise() {
  return new Promise();
}
